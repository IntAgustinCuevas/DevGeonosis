sap.ui.define([
    "devgeonosis/controller/BaseController"
], (BaseController) => {
    "use strict";

    return BaseController.extend("devgeonosis.controller.App", {
        onInit: function () {
        }
    });
});