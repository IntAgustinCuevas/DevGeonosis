/* global QUnit */

sap.ui.require(["devgeonosis/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
