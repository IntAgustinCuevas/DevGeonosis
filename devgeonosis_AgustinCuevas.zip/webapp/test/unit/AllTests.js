sap.ui.define([
	"devgeonosis/test/unit/controller/App.controller"
], function () {
	"use strict";
});
